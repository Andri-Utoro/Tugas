# Tentang Aplikasi
Aplikasi ini merupakan aplikasi hasil dari pemebelajaran di kotlin android developer expret dari Dicoding Academy.
Aplikasi ini menampilkan 
* Jadwal pertandingan berdasarkan liga.
* Daftar pertandingan yang akan datang.
* Daftar pertandingan yang sudah selesai.
* Pencarian pertandingan.
* Detail pertandingan.
* Reminder untuk pertandingan yang akan datang ke dalam calendar events.

Daftar tim berdasarkan liga.
* Daftar tim.
* Pencarian tim.
* Detail tim dilengkapi dengan daftar dan detail para pemain.

Favorite.
* Daftar tim favorite.
* Daftar pertandingan favorite.

Testing
* Menerapkan unit tests pada beberapa fungsi, misalnya fungsi untuk request data ke server.
* Menerapkan instrumentation tests dengan skenario sesuai behaviour pada aplikasi.

![alt text](https://raw.githubusercontent.com/muhrizky/FootballApps/master/sertif%20kade.png)
