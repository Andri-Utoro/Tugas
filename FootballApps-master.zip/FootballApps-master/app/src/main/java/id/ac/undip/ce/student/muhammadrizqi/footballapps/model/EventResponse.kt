package id.ac.undip.ce.student.muhammadrizqi.footballapps.model

data class EventResponse(val events: List<Event>, val event: List<Event>)