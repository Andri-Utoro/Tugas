package id.ac.undip.ce.student.muhammadrizqi.footballapps.model

data class LeagueResponse(val countrys: List<League>)