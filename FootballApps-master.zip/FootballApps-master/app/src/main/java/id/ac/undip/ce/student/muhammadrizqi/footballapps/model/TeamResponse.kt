package id.ac.undip.ce.student.muhammadrizqi.footballapps.model

data class TeamResponse (val teams: List<Team>)